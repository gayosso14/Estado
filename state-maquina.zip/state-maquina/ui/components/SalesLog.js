import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function SalesLog({ sales }) {
  if (!sales || sales.length === 0) {
    return (
      <View style={s.empty}>
        <Text style={s.emptyText}>Sin ventas aún</Text>
      </View>
    );
  }

  return (
    <View style={s.list}>
      {sales.slice(0, 5).map((sale, i) => (
        <View key={i} style={s.row}>
          <Text style={s.emoji}>{sale.item.emoji}</Text>
          <Text style={s.name}>{sale.item.name}</Text>
          <Text style={s.price}>${sale.item.price} MXN</Text>
          {sale.change > 0 && (
            <Text style={s.change}>cambio ${sale.change} MXN</Text>
          )}
        </View>
      ))}
    </View>
  );
}

const s = StyleSheet.create({
  list     : { marginBottom: 20 },
  row      : { flexDirection: 'row', alignItems: 'center', paddingVertical: 6, borderBottomWidth: 1, borderColor: '#f1f5f9', gap: 8 },
  emoji    : { fontSize: 18 },
  name     : { flex: 1, fontSize: 13, color: '#1e293b', fontWeight: '600' },
  price    : { fontSize: 13, color: '#6366f1', fontWeight: '700' },
  change   : { fontSize: 11, color: '#10b981', fontWeight: '600' },
  empty    : { paddingVertical: 10 },
  emptyText: { fontSize: 13, color: '#94a3b8', textAlign: 'center' },
});