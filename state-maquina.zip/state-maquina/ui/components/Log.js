import React from 'react';
import { View, Text, StyleSheet, Platform } from 'react-native';
 
export default function LogBox({ message }) {
  return (
    <View style={s.box}>
      <Text style={s.prompt}>{'> '}<Text style={s.msg}>{message}</Text></Text>
    </View>
  );
}
 
const s = StyleSheet.create({
  box   : { backgroundColor: '#1e293b', borderRadius: 10, padding: 12, marginBottom: 10 },
  prompt: { color: '#64748b', fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace', fontSize: 13 },
  msg   : { color: '#e2e8f0' },
});