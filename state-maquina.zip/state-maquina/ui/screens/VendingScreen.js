import React, { useState, useEffect, useRef } from 'react';
import { View, Text, ScrollView } from 'react-native';

import VendingMachine from '../../context/VendingMachine';
import { STATE_META } from '../../data/stateMeta';
import { global }     from '../../styles/globalStyles';

import StateBar      from '../components/StateBar';
import LogBox        from '../components/Log';
import MoneyDisplay  from '../components/MoneyDisplay';
import ProductGrid   from '../components/ProductGrid';
import CoinPanel     from '../components/CoinPanel';
import ActionButtons from '../components/ActionButtons';
import StateDiagram  from '../components/StateDiagram';
import SalesLog      from '../components/SalesLog';

export default function VendingScreen() {
  const [stateName, setStateName] = useState('IdleState');
  const [stateDesc, setStateDesc] = useState('Esperando selección');
  const [log,       setLog]       = useState('Selecciona un producto para comenzar.');
  const [inserted,  setInserted]  = useState(0);
  const [selected,  setSelected]  = useState(null);
  const [changeAmt, setChangeAmt] = useState(0);
  const [products,  setProducts]  = useState([]);
  const [sales,     setSales]     = useState([]);

  const machineRef = useRef(null);

  useEffect(() => {
    machineRef.current = new VendingMachine({
      setStateName,
      setStateDesc,
      setLog,
      setInserted,
      setSelected,
      setChangeAmt,
      setProducts,
      setSales,
    });
  }, []);

  const m = machineRef.current;

  const meta       = STATE_META[stateName] || STATE_META.IdleState;
  const canSelect  = stateName === 'IdleState';
  const canInsert  = ['ItemSelectedState', 'LowStockState', 'AwaitingExactChangeState'].includes(stateName);

  return (
    <ScrollView style={global.root} showsVerticalScrollIndicator={false}>

      <StateBar stateName={stateName} stateDesc={stateDesc} />
      <LogBox   message={log} />
      <MoneyDisplay inserted={inserted} selected={selected} change={changeAmt} />

      <Text style={global.sectionTitle}>Productos</Text>
      <ProductGrid
        products={products}
        selected={selected}
        canSelect={canSelect}
        onSelect={item => m?.selectItem(item)}
      />

      <Text style={global.sectionTitle}>Insertar moneda</Text>
      <CoinPanel
        canInsert={canInsert}
        onInsert={amount => m?.insertMoney(amount)}
      />

      <ActionButtons
        stateName={stateName}
        onConfirm={       () => m?.confirmPurchase()}
        onCancel={        () => m?.cancel()}
        onMaintenance={   () => m?.requestMaintenance()}
        onEndMaintenance={() => m?.endMaintenance()}
      />

      <Text style={global.sectionTitle}>Diagrama de estados</Text>
      <StateDiagram currentState={stateName} />

      <Text style={global.sectionTitle}>Últimas ventas</Text>
      <SalesLog sales={sales} />

    </ScrollView>
  );
}