import VendingMachineState from './Vending';
import IdleState           from './IdleState';
import OutOfStockState     from './OutOfStockState';

const DISPENSE_DELAY_MS = 2000;

export default class DispensingState extends VendingMachineState {

  constructor(machine) {
    super(machine);
    this._dispense();
  }

  _dispense() {
    const selected = this.machine.getSelectedItem();
    const change   = this.machine.getChange();
    const changeMsg = change > 0 ? ` Cambio: $${change.toFixed(2)}` : '';

    this.machine.decrementStock(selected.id);
    this.machine.setLog(`🎉 ¡Disfruta tu ${selected.name}!${changeMsg}`);

    this.machine.addSale({ item: selected, change, timestamp: new Date() });

    this.machine.setInsertedMoney(0);
    this.machine.setChange(0);
    this.machine.setSelectedItem(null);

    setTimeout(() => {
      const updatedItem = this.machine.getProduct(selected.id);
      if (updatedItem && updatedItem.stock === 0) {
        this.machine.setLog(`ℹ️  "${selected.name}" agotado. Selecciona otro.`);
        this.machine.transitionTo(new OutOfStockState(this.machine));
        setTimeout(() => this.machine.transitionTo(new IdleState(this.machine)), 1500);
      } else {
        this.machine.transitionTo(new IdleState(this.machine));
      }
    }, DISPENSE_DELAY_MS);
  }

  getLabel()       { return 'Dispensando'; }
  getDescription() { return 'Entregando producto...'; }
}