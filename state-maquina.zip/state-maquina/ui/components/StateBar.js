import React, { useEffect, useRef } from 'react';
import { View, Text, Animated, StyleSheet } from 'react-native';
import { STATE_META } from '../../data/stateMeta';

export default function StateBar({ stateName, stateDesc }) {
  const meta  = STATE_META[stateName] || STATE_META.IdleState;
  const scale = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.timing(scale, { toValue: 1.04, duration: 120, useNativeDriver: true }),
      Animated.timing(scale, { toValue: 1,    duration: 120, useNativeDriver: true }),
    ]).start();
  }, [stateName]);

  return (
    <Animated.View style={[s.bar, { backgroundColor: meta.bg, transform: [{ scale }] }]}>
      <View style={[s.dot, { backgroundColor: meta.color }]} />
      <View style={s.texts}>
        <Text style={[s.label, { color: meta.color }]}>{meta.label}</Text>
        <Text style={s.cls}>{stateName}</Text>
      </View>
      <Text style={[s.desc, { color: meta.color }]}>{stateDesc || meta.desc}</Text>
    </Animated.View>
  );
}

const s = StyleSheet.create({
  bar  : { flexDirection: 'row', alignItems: 'center', borderRadius: 12, padding: 10, marginBottom: 10, gap: 10 },
  dot  : { width: 10, height: 10, borderRadius: 5 },
  texts: { flex: 1 },
  label: { fontWeight: '700', fontSize: 14 },
  cls  : { fontSize: 11, color: '#94a3b8', fontFamily: 'monospace' },
  desc : { fontSize: 12, fontWeight: '600', opacity: 0.85 },
});