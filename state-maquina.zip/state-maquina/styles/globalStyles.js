import { StyleSheet, Platform } from 'react-native';

export const colors = {
  bg       : '#f8fafc',
  surface  : '#ffffff',
  border   : '#e2e8f0',
  textPri  : '#1e293b',
  textSec  : '#64748b',
  textHint : '#94a3b8',
  mono     : Platform.OS === 'ios' ? 'Menlo' : 'monospace',
};

export const global = StyleSheet.create({
  root: {
    flex             : 1,
    backgroundColor  : colors.bg,
    paddingTop       : Platform.OS === 'ios' ? 54 : 32,
    paddingHorizontal: 16,
  },
  sectionTitle: {
    fontSize     : 11,
    fontWeight   : '700',
    color        : colors.textHint,
    marginBottom : 8,
    marginTop    : 6,
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  card: {
    backgroundColor: colors.surface,
    borderRadius   : 12,
    borderWidth    : 1,
    borderColor    : colors.border,
    padding        : 12,
  },
  row: {
    flexDirection: 'row',
    gap          : 10,
  },
});