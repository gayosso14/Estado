import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity,
  TextInput, StyleSheet, Alert,
} from 'react-native';

const QUICK_AMOUNTS = [5, 10, 20, 50, 100];

export default function CoinPanel({ canInsert, onInsert }) {
  const [input, setInput] = useState('');

  const handleInsert = (amount) => {
    const value = Number(amount);
    if (isNaN(value) || value <= 0) {
      Alert.alert('Cantidad inválida', 'Ingresa un número mayor a 0.');
      return;
    }
    if (value > 500) {
      Alert.alert('Límite excedido', 'El máximo por inserción es $500 MXN.');
      return;
    }
    onInsert(value);
    setInput('');
  };

  const handleCustom = () => {
    if (!input.trim()) return;
    handleInsert(parseFloat(input));
  };

  return (
    <View style={s.container}>
      <View style={s.quickRow}>
        {QUICK_AMOUNTS.map(a => (
          <TouchableOpacity
            key={a}
            style={[s.quickBtn, !canInsert && s.btnOff]}
            onPress={() => handleInsert(a)}
            disabled={!canInsert}
          >
            <Text style={[s.quickText, !canInsert && s.textOff]}>${a}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={[s.inputRow, !canInsert && s.inputRowOff]}>
        <Text style={[s.peso, !canInsert && s.textOff]}>$</Text>
        <TextInput
          style={[s.input, !canInsert && s.inputOff]}
          placeholder="Otra cantidad"
          placeholderTextColor="#94a3b8"
          keyboardType="numeric"
          returnKeyType="done"
          value={input}
          onChangeText={setInput}
          onSubmitEditing={handleCustom}
          editable={canInsert}
        />
        <TouchableOpacity
          style={[s.insertBtn, (!canInsert || !input.trim()) && s.btnOff]}
          onPress={handleCustom}
          disabled={!canInsert || !input.trim()}
        >
          <Text style={[s.insertText, (!canInsert || !input.trim()) && s.textOff]}>
            Insertar
          </Text>
        </TouchableOpacity>
      </View>

      {canInsert && (
        <Text style={s.hint}>MXN · Monedas desde $1 · Billetes hasta $500</Text>
      )}
    </View>
  );
}

const s = StyleSheet.create({
  container  : { marginBottom: 14 },
  quickRow   : { flexDirection: 'row', gap: 7, marginBottom: 8 },
  quickBtn   : { flex: 1, backgroundColor: '#fff', borderRadius: 10, borderWidth: 1.5, borderColor: '#f59e0b', paddingVertical: 11, alignItems: 'center' },
  quickText  : { fontWeight: '700', color: '#f59e0b', fontSize: 14 },
  btnOff     : { borderColor: '#e2e8f0', backgroundColor: '#f8fafc' },
  textOff    : { color: '#cbd5e1' },
  inputRow   : { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', borderRadius: 12, borderWidth: 1.5, borderColor: '#6366f1', paddingHorizontal: 12, gap: 8 },
  inputRowOff: { borderColor: '#e2e8f0', backgroundColor: '#f8fafc' },
  peso       : { fontSize: 18, fontWeight: '700', color: '#6366f1' },
  input      : { flex: 1, fontSize: 18, fontWeight: '600', color: '#1e293b', paddingVertical: 12 },
  inputOff   : { color: '#cbd5e1' },
  insertBtn  : { backgroundColor: '#6366f1', borderRadius: 8, paddingHorizontal: 14, paddingVertical: 8 },
  insertText : { color: '#fff', fontWeight: '700', fontSize: 13 },
  hint       : { fontSize: 11, color: '#94a3b8', marginTop: 6, textAlign: 'center' },
});