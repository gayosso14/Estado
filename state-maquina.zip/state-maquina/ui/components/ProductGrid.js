import React from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';

function stockColor(stock) {
  if (stock === 0) return '#ef4444';
  if (stock === 1) return '#f59e0b';
  return '#10b981';
}

export default function ProductGrid({ products, selected, canSelect, onSelect }) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 14 }}>
      {products.map(p => {
        const isSelected = selected?.id === p.id;
        const outOfStock = p.stock === 0;
        const lowStock   = p.stock === 1;
        return (
          <TouchableOpacity
            key={p.id}
            style={[
              s.card,
              isSelected && s.cardSelected,
              outOfStock  && s.cardOut,
              !canSelect  && s.cardDisabled,
            ]}
            onPress={() => onSelect(p)}
            disabled={!canSelect}
            activeOpacity={0.75}
          >
            <Text style={s.emoji}>{p.emoji}</Text>
            <Text style={s.name}>{p.name}</Text>
            <Text style={s.price}>${p.price} MXN</Text>
            <View style={[s.stockBadge, { backgroundColor: stockColor(p.stock) + '22' }]}>
              <Text style={[s.stockText, { color: stockColor(p.stock) }]}>
                {outOfStock ? 'Agotado' : lowStock ? '¡Último!' : `Stock: ${p.stock}`}
              </Text>
            </View>
          </TouchableOpacity>
        );
      })}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  card        : { backgroundColor: '#fff', borderRadius: 14, borderWidth: 1.5, borderColor: '#e2e8f0', padding: 14, marginRight: 10, alignItems: 'center', width: 116 },
  cardSelected: { borderColor: '#6366f1', backgroundColor: '#eef2ff' },
  cardOut     : { opacity: 0.5 },
  cardDisabled: { opacity: 0.6 },
  emoji       : { fontSize: 30, marginBottom: 4 },
  name        : { fontSize: 12, fontWeight: '600', textAlign: 'center', color: '#1e293b' },
  price       : { fontSize: 14, fontWeight: '700', color: '#6366f1', marginTop: 4 },
  stockBadge  : { marginTop: 6, borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 },
  stockText   : { fontSize: 10, fontWeight: '700' },
});