import { IdleState } from '../states';

export default class VendingMachine {
  constructor(callbacks) {
    this._cb = {
      setStateName : callbacks.setStateName,
      setStateDesc : callbacks.setStateDesc,
      setLog       : callbacks.setLog,
      setInserted  : callbacks.setInserted,
      setSelected  : callbacks.setSelected,
      setChangeAmt : callbacks.setChangeAmt,
      setProducts  : callbacks.setProducts,
      setSales     : callbacks.setSales,
    };

    this._insertedMoney   = 0;
    this._selectedItem    = null;
    this._change          = 0;
    this._availableChange = 200; 
    this._sales           = [];

    this._products = [
      { id: 1, name: 'Coca-Cola',     price: 18, emoji: '🥤', stock: 3 },
      { id: 2, name: 'Papas Lays',    price: 15, emoji: '🍟', stock: 2 },
      { id: 3, name: 'Agua',          price: 12, emoji: '💧', stock: 1 }, 
      { id: 4, name: 'Snickers',      price: 22, emoji: '🍫', stock: 5 }, 
      { id: 5, name: 'Jugo Naranja',  price: 20, emoji: '🍊', stock: 2 },
      { id: 6, name: 'Café',          price: 25, emoji: '☕', stock: 1 }, 
      { id: 7, name: 'Galletas Oreo', price: 14, emoji: '🍪', stock: 4 },
      { id: 8, name: 'Gatorade',      price: 28, emoji: '⚡', stock: 2 },
    ];

    this._state = new IdleState(this);
    this._syncState();
    this._cb.setProducts([...this._products]);
    this._cb.setSales([]);
  }


  selectItem(item)    { this._state.selectItem(item); }
  insertMoney(amount) { this._state.insertMoney(amount); }
  confirmPurchase()   { this._state.confirmPurchase(); }
  cancel()            { this._state.cancel(); }
  requestMaintenance(){ this._state.requestMaintenance(); }
  endMaintenance()    { this._state.endMaintenance(); }
  refund()            { this._state.refund(); }

  restock(productId, quantity) {
    if (this._state.restock) {
      this._state.restock(productId, quantity);
    } else {
      this.setLog('⚠️  Solo se puede reabastecer en modo mantenimiento.');
    }
  }


  transitionTo(newState) {
    this._state = newState;
    this._syncState();
  }

  _syncState() {
    this._cb.setStateName(this._state.constructor.name);
    this._cb.setStateDesc(this._state.getDescription());
  }


  getInsertedMoney()   { return this._insertedMoney; }
  getSelectedItem()    { return this._selectedItem; }
  getChange()          { return this._change; }
  getAvailableChange() { return this._availableChange; }
  getProduct(id)       { return this._products.find(p => p.id === id) || null; }


  setInsertedMoney(v) {
    this._insertedMoney = v;
    this._cb.setInserted(v);
  }

  setSelectedItem(v) {
    this._selectedItem = v;
    this._cb.setSelected(v);
  }

  setChange(v) {
    this._change = v;
    this._cb.setChangeAmt(v);
  }

  setLog(msg) {
    this._cb.setLog(msg);
  }


  decrementStock(id) {
    this._products = this._products.map(p =>
      p.id === id ? { ...p, stock: Math.max(0, p.stock - 1) } : p
    );
    this._cb.setProducts([...this._products]);
  }

  restockProduct(id, quantity) {
    this._products = this._products.map(p =>
      p.id === id ? { ...p, stock: p.stock + quantity } : p
    );
    this._cb.setProducts([...this._products]);
  }


  addSale(sale) {
    this._sales = [sale, ...this._sales].slice(0, 20); 
    this._cb.setSales([...this._sales]);
    this._availableChange = parseFloat(
      Math.max(0, this._availableChange - sale.change).toFixed(0)
    );
  }
}