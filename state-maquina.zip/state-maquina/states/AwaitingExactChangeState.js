import VendingMachineState    from './Vending';
import ProcessingPaymentState from './ProcessingPaymentState';
import RefundingState         from './RefundingState';

export default class AwaitingExactChangeState extends VendingMachineState {

  insertMoney(amount) {
    const total    = this.machine.getInsertedMoney() + amount;
    const selected = this.machine.getSelectedItem();
    this.machine.setInsertedMoney(total);

    if (total === selected.price) {
      this.machine.setLog(`✅ Monto exacto recibido. Procesando...`);
      this.machine.transitionTo(new ProcessingPaymentState(this.machine));
    } else if (total > selected.price) {
      this.machine.setLog(
        `⚠️  Monto excedido ($${total.toFixed(2)}). Iniciando reembolso...`
      );
      this.machine.transitionTo(new RefundingState(this.machine));
    } else {
      this.machine.setLog(
        `💵 $${amount.toFixed(2)} recibido. Faltan $${(selected.price - total).toFixed(2)} (exactos).`
      );
    }
  }

  cancel() {
    this.machine.setLog(`↩️  Cancelado. Iniciando reembolso de $${this.machine.getInsertedMoney().toFixed(2)}...`);
    this.machine.transitionTo(new RefundingState(this.machine));
  }

  getLabel()       { return 'Sin cambio'; }
  getDescription() { return 'Se requiere monto exacto'; }
}