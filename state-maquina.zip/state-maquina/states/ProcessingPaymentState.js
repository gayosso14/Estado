import VendingMachineState from './Vending';
import DispensingState     from './DispensingState';
import RefundingState      from './RefundingState';

export default class ProcessingPaymentState extends VendingMachineState {

  confirmPurchase() {
    const selected = this.machine.getSelectedItem();
    const inserted = this.machine.getInsertedMoney();
    const change   = parseFloat((inserted - selected.price).toFixed(2));

    this.machine.setLog(`🔄 Procesando pago de $${selected.price.toFixed(2)}...`);
    this.machine.setChange(change);
    this.machine.transitionTo(new DispensingState(this.machine));
  }

  cancel() {
    this.machine.setLog(
      `↩️  Pago cancelado. Devolviendo $${this.machine.getInsertedMoney().toFixed(2)}...`
    );
    this.machine.transitionTo(new RefundingState(this.machine));
  }

  getLabel()       { return 'Procesando pago'; }
  getDescription() { return 'Confirma o cancela la compra'; }
}