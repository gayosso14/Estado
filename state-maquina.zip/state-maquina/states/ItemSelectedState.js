import VendingMachineState      from './Vending';
import ProcessingPaymentState   from './ProcessingPaymentState';
import AwaitingExactChangeState from './AwaitingExactChangeState';
import IdleState                from './IdleState';

export default class ItemSelectedState extends VendingMachineState {

  constructor(machine, isLowStock = false) {
    super(machine);
    this.isLowStock = isLowStock;
  }

  insertMoney(amount) {
    const total    = this.machine.getInsertedMoney() + amount;
    const selected = this.machine.getSelectedItem();
    this.machine.setInsertedMoney(total);
    this.machine.setLog(
      `💵 $${amount.toFixed(2)} insertado — Total: $${total.toFixed(2)} / $${selected.price.toFixed(2)}`
    );

    if (total >= selected.price) {
      const change = parseFloat((total - selected.price).toFixed(2));
      if (change > 0 && this.machine.getAvailableChange() < change) {
        this.machine.setLog(
          `⚠️  Sin cambio para $${change.toFixed(2)}. Por favor ingresa el monto exacto.`
        );
        this.machine.transitionTo(new AwaitingExactChangeState(this.machine));
      } else {
        this.machine.transitionTo(new ProcessingPaymentState(this.machine));
      }
    }
  }

  cancel() {
    const refund = this.machine.getInsertedMoney();
    this.machine.setInsertedMoney(0);
    this.machine.setSelectedItem(null);
    this.machine.setLog(`↩️  Cancelado. Reembolso: $${refund.toFixed(2)}`);
    this.machine.transitionTo(new IdleState(this.machine));
  }

  getLabel()       { return this.isLowStock ? 'Stock bajo — Pago' : 'Artículo seleccionado'; }
  getDescription() { return 'Inserta dinero para continuar'; }
}