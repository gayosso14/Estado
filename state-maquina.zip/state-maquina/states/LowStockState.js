import VendingMachineState         from './Vending';
import ItemSelectedState           from './ItemSelectedState';
import IdleState                   from './IdleState';
import AwaitingExactChangeState    from './AwaitingExactChangeState';

export default class LowStockState extends VendingMachineState {

  insertMoney(amount) {
    const total    = this.machine.getInsertedMoney() + amount;
    const selected = this.machine.getSelectedItem();
    this.machine.setInsertedMoney(total);
    this.machine.setLog(
      `💵 $${amount.toFixed(2)} insertado — Total: $${total.toFixed(2)} / $${selected.price.toFixed(2)}`
    );

    if (total >= selected.price) {
      const change = parseFloat((total - selected.price).toFixed(2));
      if (change > 0 && this.machine.getAvailableChange() < change) {
        this.machine.setLog(
          `⚠️  Sin cambio disponible. Necesitamos $${selected.price.toFixed(2)} exactos.`
        );
        this.machine.transitionTo(new AwaitingExactChangeState(this.machine));
      } else {
        this.machine.transitionTo(new ItemSelectedState(this.machine, true /* lowStock */));
      }
    }
  }

  cancel() {
    const refund = this.machine.getInsertedMoney();
    this.machine.setInsertedMoney(0);
    this.machine.setSelectedItem(null);
    this.machine.setLog(`↩️  Cancelado. Reembolso: $${refund.toFixed(2)}`);
    this.machine.transitionTo(new IdleState(this.machine));
  }

  getLabel()       { return 'Stock bajo'; }
  getDescription() { return 'Último artículo disponible'; }
}