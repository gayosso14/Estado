import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { STATE_META } from '../../data/stateMeta';

const BUTTON_CONFIG = {
  confirm       : { label: '✔ Confirmar',     bg: '#10b981' },
  cancel        : { label: '✖ Cancelar',      bg: '#ef4444' },
  maintenance   : { label: '🔧 Mantenimiento', bg: '#64748b' },
  endMaintenance: { label: '✅ Finalizar mant.', bg: '#6366f1' },
};

export default function ActionButtons({ stateName, onConfirm, onCancel, onMaintenance, onEndMaintenance }) {
  const meta    = STATE_META[stateName] || STATE_META.IdleState;
  const actions = meta.actions;

  const handlers = {
    confirm       : onConfirm,
    cancel        : onCancel,
    maintenance   : onMaintenance,
    endMaintenance: onEndMaintenance,
  };

  if (actions.length === 0) return null;

  return (
    <View style={s.row}>
      {actions
        .filter(a => BUTTON_CONFIG[a])
        .map(a => {
          const cfg = BUTTON_CONFIG[a];
          return (
            <TouchableOpacity
              key={a}
              style={[s.btn, { backgroundColor: cfg.bg }]}
              onPress={handlers[a]}
            >
              <Text style={s.btnText}>{cfg.label}</Text>
            </TouchableOpacity>
          );
        })}
    </View>
  );
}

const s = StyleSheet.create({
  row    : { flexDirection: 'row', gap: 10, marginBottom: 14 },
  btn    : { flex: 1, borderRadius: 12, paddingVertical: 14, alignItems: 'center' },
  btnText: { color: '#fff', fontWeight: '700', fontSize: 14 },
});