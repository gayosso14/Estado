import VendingMachineState from './Vending';
import IdleState           from './IdleState';

const REFUND_DELAY_MS = 1500;

export default class RefundingState extends VendingMachineState {

  constructor(machine) {
    super(machine);
    this._refund();
  }

  _refund() {
    const amount = this.machine.getInsertedMoney();
    this.machine.setLog(`💸 Reembolsando $${amount.toFixed(2)}... por favor espera.`);

    this.machine.setInsertedMoney(0);
    this.machine.setChange(0);
    this.machine.setSelectedItem(null);

    setTimeout(() => {
      this.machine.setLog(`✅ Reembolso de $${amount.toFixed(2)} completado.`);
      this.machine.transitionTo(new IdleState(this.machine));
    }, REFUND_DELAY_MS);
  }

  getLabel()       { return 'Reembolsando'; }
  getDescription() { return 'Devolviendo dinero...'; }
}