import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const fmt = (n) => `$${Number(n).toFixed(0)} MXN`;

function Stat({ label, value, color }) {
  return (
    <View style={s.stat}>
      <Text style={s.label}>{label}</Text>
      <Text style={[s.value, color && { color }]}>{fmt(value)}</Text>
    </View>
  );
}

export default function MoneyDisplay({ inserted, selected, change }) {
  return (
    <View style={s.row}>
      <Stat label="Insertado" value={inserted} />
      {selected   && <Stat label="Precio"  value={selected.price} color="#6366f1" />}
      {change > 0 && <Stat label="Cambio"  value={change}         color="#10b981" />}
    </View>
  );
}

const s = StyleSheet.create({
  row  : { flexDirection: 'row', gap: 10, marginBottom: 12 },
  stat : { flex: 1, backgroundColor: '#fff', borderRadius: 10, borderWidth: 1, borderColor: '#e2e8f0', padding: 10, alignItems: 'center' },
  label: { fontSize: 11, color: '#94a3b8', marginBottom: 2 },
  value: { fontSize: 17, fontWeight: '700', color: '#1e293b' },
});