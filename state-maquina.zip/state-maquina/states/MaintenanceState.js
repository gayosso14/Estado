import VendingMachineState from './Vending';
import IdleState           from './IdleState';

export default class MaintenanceState extends VendingMachineState {

  constructor(machine) {
    super(machine);

    const money = machine.getInsertedMoney();
    if (money > 0) {
      machine.setLog(`🔧 Mantenimiento iniciado. Reembolsando $${money.toFixed(2)} en tránsito.`);
      machine.setInsertedMoney(0);
      machine.setSelectedItem(null);
      machine.setChange(0);
    } else {
      machine.setLog('🔧 Máquina en mantenimiento. Fuera de servicio.');
    }
  }

  endMaintenance() {
    this.machine.setLog('✅ Mantenimiento finalizado. Máquina lista.');
    this.machine.transitionTo(new IdleState(this.machine));
  }

  restock(productId, quantity) {
    this.machine.restockProduct(productId, quantity);
    this.machine.setLog(`📦 Producto #${productId} reabastecido (+${quantity} unidades).`);
  }

  getLabel()       { return 'Mantenimiento'; }
  getDescription() { return 'Fuera de servicio'; }
}