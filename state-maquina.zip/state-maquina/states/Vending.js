export default class VendingMachineState {
  constructor(machine) {
    this.machine = machine;
  }

  selectItem(_item)    { this._invalid('selectItem'); }
  insertMoney(_amount) { this._invalid('insertMoney'); }
  confirmPurchase()    { this._invalid('confirmPurchase'); }
  cancel()             { this._invalid('cancel'); }
  requestMaintenance() { this._invalid('requestMaintenance'); }
  endMaintenance()     { this._invalid('endMaintenance'); }
  refund()             { this._invalid('refund'); }

  _invalid(action) {
    this.machine.setLog(
      `⚠️  "${action}" no está permitido en ${this.constructor.name}`
    );
  }

  getLabel()       { return this.constructor.name; }
  getDescription() { return ''; }
}