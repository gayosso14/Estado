import React from 'react';
import VendingScreen from './ui/screens/VendingScreen';
 
export default function App() {
  return <VendingScreen />;
}