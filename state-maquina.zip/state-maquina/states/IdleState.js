import VendingMachineState from './Vending';
import ItemSelectedState   from './ItemSelectedState';
import OutOfStockState     from './OutOfStockState';
import LowStockState       from './LowStockState';
import MaintenanceState    from './MaintenanceState';

export default class IdleState extends VendingMachineState {

  selectItem(item) {
    if (item.stock === 0) {
      this.machine.setLog(`❌ "${item.name}" está agotado.`);
      this.machine.transitionTo(new OutOfStockState(this.machine));
      return;
    }

    if (item.stock === 1) {
      this.machine.setSelectedItem(item);
      this.machine.setLog(
        `⚠️  Último "${item.name}" disponible — $${item.price.toFixed(2)}`
      );
      this.machine.transitionTo(new LowStockState(this.machine));
      return;
    }

    this.machine.setSelectedItem(item);
    this.machine.setLog(`✅ Seleccionaste: ${item.name} — $${item.price.toFixed(2)}`);
    this.machine.transitionTo(new ItemSelectedState(this.machine));
  }

  requestMaintenance() {
    this.machine.setLog('🔧 Entrando en modo mantenimiento...');
    this.machine.transitionTo(new MaintenanceState(this.machine));
  }

  getLabel()       { return 'Idle'; }
  getDescription() { return 'Esperando selección'; }
}