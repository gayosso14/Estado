import VendingMachineState from './Vending';
import IdleState           from './IdleState';

export default class OutOfStockState extends VendingMachineState {

  cancel() {
    this.machine.setLog('🔄 Volviendo al menú...');
    this.machine.transitionTo(new IdleState(this.machine));
  }

  getLabel()       { return 'Sin stock'; }
  getDescription() { return 'Producto agotado'; }
}