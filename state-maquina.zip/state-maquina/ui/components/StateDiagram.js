import React from 'react';
import { ScrollView, View, Text, StyleSheet } from 'react-native';
import { STATE_META } from '../../data/stateMeta';

const ORDER = [
  'IdleState',
  'LowStockState',
  'ItemSelectedState',
  'AwaitingExactChangeState',
  'ProcessingPaymentState',
  'DispensingState',
  'RefundingState',
  'OutOfStockState',
  'MaintenanceState',
];

export default function StateDiagram({ currentState }) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 20 }}>
      {ORDER.map((name, i) => {
        const meta   = STATE_META[name] || {};
        const active = name === currentState;
        return (
          <View key={name} style={s.item}>
            <View style={[s.node, { borderColor: meta.color, backgroundColor: active ? meta.bg : '#fff' }]}>
              <Text style={[s.nodeText, { color: meta.color }]}>{meta.label}</Text>
            </View>
            {i < ORDER.length - 1 && <Text style={s.arrow}>→</Text>}
          </View>
        );
      })}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  item    : { flexDirection: 'row', alignItems: 'center' },
  node    : { borderWidth: 2, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 5 },
  nodeText: { fontSize: 10, fontWeight: '700' },
  arrow   : { fontSize: 14, color: '#cbd5e1', marginHorizontal: 3 },
});